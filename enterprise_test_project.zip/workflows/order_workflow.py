
from services.payment_service import PaymentService
from patterns.observer import EventManager

class OrderWorkflow:

    def __init__(
        self,
        payment_service: PaymentService,
        event_manager: EventManager
    ):
        self.payment_service = payment_service
        self.event_manager = event_manager

    def execute(self, amount: float):
        result = self.payment_service.process_payment(amount)

        self.event_manager.notify(
            f"Payment completed for {amount}"
        )

        return result
