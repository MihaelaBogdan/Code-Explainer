
from services.payment_service import (
    StripeProvider,
    PaypalProvider
)

class PaymentFactory:

    @staticmethod
    def create(provider_name: str):

        providers = {
            "stripe": StripeProvider,
            "paypal": PaypalProvider
        }

        provider_cls = providers.get(provider_name.lower())

        if not provider_cls:
            raise ValueError("Unsupported provider")

        return provider_cls()
