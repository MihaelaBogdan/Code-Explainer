
class Observer:

    def update(self, event):
        raise NotImplementedError

class EmailNotifier(Observer):

    def update(self, event):
        print(f"EMAIL: {event}")

class AuditLogger(Observer):

    def update(self, event):
        print(f"AUDIT: {event}")

class EventManager:

    def __init__(self):
        self.observers = []

    def subscribe(self, observer):
        self.observers.append(observer)

    def notify(self, event):
        for observer in self.observers:
            observer.update(event)
