
from dataclasses import dataclass, field
from typing import List
from datetime import datetime

@dataclass
class Address:
    city: str
    street: str
    postal_code: str

@dataclass
class User:
    id: int
    email: str
    created_at: datetime
    addresses: List[Address] = field(default_factory=list)

    def add_address(self, address: Address):
        self.addresses.append(address)

@dataclass
class Employee(User):
    department: str = ""
    salary: float = 0.0

    def yearly_salary(self):
        return self.salary * 12
