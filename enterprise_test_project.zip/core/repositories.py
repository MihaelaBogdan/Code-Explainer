
from abc import ABC, abstractmethod
from typing import List
from core.entities import User

class Repository(ABC):

    @abstractmethod
    def save(self, entity):
        pass

    @abstractmethod
    def get_all(self):
        pass

class UserRepository(Repository):

    def __init__(self):
        self._users = []

    def save(self, entity: User):
        self._users.append(entity)

    def get_all(self) -> List[User]:
        return self._users

    def find_by_email(self, email: str):
        return next((u for u in self._users if u.email == email), None)
