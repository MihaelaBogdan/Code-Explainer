
from core.entities import Employee
from core.repositories import UserRepository
from services.auth_service import AuthService
from services.payment_service import PaymentService
from patterns.factory import PaymentFactory
from controllers.user_controller import UserController

repo = UserRepository()

employee = Employee(
    id=1,
    email="john@corp.local",
    department="Engineering",
    salary=5000,
    created_at=None
)

repo.save(employee)

auth_service = AuthService(repo)

provider = PaymentFactory.create("stripe")

payment_service = PaymentService(provider)

controller = UserController(
    auth_service,
    payment_service
)

print(controller.pay_subscription(49.99))
