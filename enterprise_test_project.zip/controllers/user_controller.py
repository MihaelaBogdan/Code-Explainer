
from services.auth_service import AuthService
from services.payment_service import PaymentService

class UserController:

    def __init__(
        self,
        auth_service: AuthService,
        payment_service: PaymentService
    ):
        self.auth_service = auth_service
        self.payment_service = payment_service

    def authenticate(self, email, password):
        return self.auth_service.login(email, password)

    def pay_subscription(self, amount):
        return self.payment_service.process_payment(amount)
