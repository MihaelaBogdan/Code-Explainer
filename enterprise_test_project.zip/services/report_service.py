
from core.repositories import UserRepository

class CsvExporter:

    def export(self, users):
        return "\n".join([u.email for u in users])

class PdfExporter:

    def export(self, users):
        return f"PDF_REPORT<{len(users)}>"

class ReportService:

    def __init__(self, repo: UserRepository):
        self.repo = repo

    def generate(self, exporter):
        users = self.repo.get_all()
        return exporter.export(users)
