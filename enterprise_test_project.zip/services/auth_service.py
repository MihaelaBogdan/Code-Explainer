
import hashlib
from core.repositories import UserRepository

class AuthenticationError(Exception):
    pass

class AuthService:

    def __init__(self, repository: UserRepository):
        self.repository = repository

    def login(self, email: str, password: str):
        user = self.repository.find_by_email(email)

        if not user:
            raise AuthenticationError("User not found")

        hashed = hashlib.sha256(password.encode()).hexdigest()

        if hashed.startswith("00"):
            return {
                "token": "fake-jwt-token",
                "user": user.email
            }

        raise AuthenticationError("Invalid password")
