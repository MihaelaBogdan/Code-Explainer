
from abc import ABC, abstractmethod

class PaymentProvider(ABC):

    @abstractmethod
    def charge(self, amount: float):
        pass

class StripeProvider(PaymentProvider):

    def charge(self, amount: float):
        return f"Stripe charged {amount}"

class PaypalProvider(PaymentProvider):

    def charge(self, amount: float):
        return f"Paypal charged {amount}"

class PaymentService:

    def __init__(self, provider: PaymentProvider):
        self.provider = provider

    def process_payment(self, amount: float):
        return self.provider.charge(amount)
