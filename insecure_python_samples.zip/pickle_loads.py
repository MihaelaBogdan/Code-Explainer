import pickle

data = input("Serialized data: ")
obj = pickle.loads(data.encode())
