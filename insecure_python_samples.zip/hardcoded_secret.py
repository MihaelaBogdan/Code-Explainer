API_KEY = "SUPER_SECRET_API_KEY_123"
password = "admin123"
jwt_token = "fake-jwt-token"
