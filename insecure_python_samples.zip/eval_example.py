user_input = input("Code: ")
eval(user_input)
