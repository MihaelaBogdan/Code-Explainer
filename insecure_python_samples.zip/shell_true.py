import subprocess

cmd = input("Command: ")
subprocess.run(cmd, shell=True)
