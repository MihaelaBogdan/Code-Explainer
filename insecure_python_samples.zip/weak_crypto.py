import hashlib

password = "secret123"
hash_value = hashlib.md5(password.encode()).hexdigest()

print(hash_value)
