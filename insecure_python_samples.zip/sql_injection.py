user_id = input("User ID: ")

query = "SELECT * FROM users WHERE id = " + user_id

cursor.execute(query)
