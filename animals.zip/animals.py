class Animal:
    def eat(self):
        pass

class Dog(Animal):
    def __init__(self):
        self.name = "Rex"

    def bark(self):
        pass

class Cat(Animal):
    def meow(self):
        pass