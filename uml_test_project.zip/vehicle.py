class Engine:
    def start(self):
        pass

class Vehicle:
    def __init__(self):
        self.speed = 0

    def move(self):
        pass

class Car(Vehicle):
    def __init__(self):
        self.engine = Engine()
        self.brand = "BMW"

    def drive(self):
        pass