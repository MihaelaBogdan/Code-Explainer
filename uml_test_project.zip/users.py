class Database:
    def connect(self):
        pass

class UserRepository:
    def __init__(self):
        self.db = Database()

    def save_user(self):
        pass

class UserService:
    def __init__(self):
        self.repo = UserRepository()

    def create_user(self):
        pass

    def delete_user(self):
        pass